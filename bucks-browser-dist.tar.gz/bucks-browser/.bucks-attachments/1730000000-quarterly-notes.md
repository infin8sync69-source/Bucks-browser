# Q3 Infrastructure Notes

## Storage
- IPFS pinning grew to 4.2 TB across 6 nodes
- Kubo 0.41 upgrade completed on 2026-06-12

## Incidents
- INC-441: gateway timeout, 38 min, cause = NAT reachability
- INC-447: chain.json truncated to 0 bytes on hard shutdown

## Decisions
- Adopt atomic writes for all persisted state
- Defer distributed inference to next quarter
